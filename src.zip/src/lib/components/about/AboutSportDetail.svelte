<script>
  import { tick, onMount } from 'svelte';
  import {
    getHotspotPathIndex,
    ABOUT_HOTSPOT_PATH,
    ABOUT_PANEL_MOBILE_BREAKPOINT
  } from '$lib/components/3d/aboutHotspots.js';

  /** @type {{
   *   hotspot: import('$lib/components/3d/aboutHotspots.js').AboutHotspot;
   *   onclose: () => void;
   *   onnext?: () => void;
   * }} */
  let { hotspot, onclose, onnext } = $props();

  const pathIndex = $derived(getHotspotPathIndex(hotspot.id));
  const hasNext = $derived(pathIndex >= 0 && ABOUT_HOTSPOT_PATH.length > 1);
  const title = $derived(hotspot.title ?? hotspot.label);
  let isMobilePanel = $state(false);
  const bodyLines = $derived(
    (isMobilePanel ? hotspot.bodyMobile ?? hotspot.body : hotspot.body).split('\n')
  );

  /** @type {HTMLElement | null} */
  let panelEl = $state(null);
  /** @type {HTMLElement | null} */
  let scrollEl = $state(null);
  /** @type {HTMLElement | null} */
  let contentEl = $state(null);
  /** @type {HTMLElement | null} */
  let titleEl = $state(null);
  let canScroll = $state(false);
  let scrollRatio = $state(0);
  let thumbRatio = $state(1);
  let sliderTop = $state(0);
  let sliderTrackHeight = $state(0);
  let scrollAdvanceLockUntil = 0;
  let scrollAdvanceAccum = 0;
  let touchStartY = 0;
  let touchLastY = 0;

  const SCROLL_WHEEL_FACTOR = 0.42;
  const SCROLL_ADVANCE_THRESHOLD = 260;
  const TOUCH_ADVANCE_THRESHOLD = 12;

  function measureSliderFrame() {
    if (!scrollEl || !contentEl || !titleEl) return;

    const contentStyles = getComputedStyle(contentEl);
    const paddingTop = Number.parseFloat(contentStyles.paddingTop) || 0;
    sliderTop = contentEl.offsetTop + paddingTop + titleEl.offsetTop;
    sliderTrackHeight = Math.max(0, scrollEl.clientHeight - sliderTop);
  }

  function syncSlider() {
    if (!scrollEl) return;
    const { scrollTop, scrollHeight, clientHeight } = scrollEl;
    const maxScroll = scrollHeight - clientHeight;
    canScroll = maxScroll > 4;
    scrollRatio = maxScroll > 0 ? scrollTop / maxScroll : 0;
    thumbRatio =
      scrollHeight > 0 ? Math.max(0.14, Math.min(1, clientHeight / scrollHeight)) : 1;
    measureSliderFrame();
    if (!isScrollAtBottom()) scrollAdvanceAccum = 0;
  }

  /** @param {number} value @param {number} min @param {number} max */
  function clamp(value, min, max) {
    return Math.min(max, Math.max(min, value));
  }

  /** @param {PointerEvent} event */
  function onTrackPointerDown(event) {
    if (!scrollEl || !canScroll || event.target !== event.currentTarget) return;
    const track = /** @type {HTMLElement} */ (event.currentTarget);
    const rect = track.getBoundingClientRect();
    const thumbHeight = thumbRatio * rect.height;
    const y = event.clientY - rect.top - thumbHeight / 2;
    const ratio = clamp(y / Math.max(rect.height - thumbHeight, 1), 0, 1);
    scrollEl.scrollTop = ratio * (scrollEl.scrollHeight - scrollEl.clientHeight);
    syncSlider();
  }

  /** @param {PointerEvent} event */
  function onThumbPointerDown(event) {
    if (!scrollEl || !canScroll) return;
    event.preventDefault();
    event.stopPropagation();

    const startY = event.clientY;
    const startScroll = scrollEl.scrollTop;
    const maxScroll = scrollEl.scrollHeight - scrollEl.clientHeight;
    const trackHeightPx = sliderTrackHeight;
    const thumbHeightPx = thumbRatio * trackHeightPx;

    /** @param {PointerEvent} moveEvent */
    const onMove = (moveEvent) => {
      const delta = moveEvent.clientY - startY;
      const scrollDelta =
        (delta / Math.max(trackHeightPx - thumbHeightPx, 1)) * maxScroll;
      scrollEl.scrollTop = clamp(startScroll + scrollDelta, 0, maxScroll);
      syncSlider();
    };

    const onUp = () => {
      window.removeEventListener('pointermove', onMove);
      window.removeEventListener('pointerup', onUp);
    };

    window.addEventListener('pointermove', onMove);
    window.addEventListener('pointerup', onUp);
  }

  async function fitPanelContent() {
    await tick();
    if (!panelEl || !contentEl) return;

    contentEl.style.zoom = '1';
    syncSlider();
  }

  async function resetPanelForHotspot() {
    await tick();
    if (scrollEl) scrollEl.scrollTop = 0;
    await fitPanelContent();
  }

  $effect(() => {
    hotspot.id;
    bodyLines.length;
    scrollAdvanceAccum = 0;
    resetPanelForHotspot();
  });

  $effect(() => {
    if (!panelEl || !scrollEl || !contentEl || !titleEl) return;

    const observer = new ResizeObserver(() => {
      fitPanelContent();
      syncSlider();
    });
    observer.observe(panelEl);
    observer.observe(scrollEl);
    observer.observe(contentEl);
    observer.observe(titleEl);

    return () => observer.disconnect();
  });

  onMount(() => {
    const syncIsMobilePanel = () => {
      isMobilePanel = window.innerWidth <= ABOUT_PANEL_MOBILE_BREAKPOINT;
    };

    syncIsMobilePanel();

    document.fonts?.ready.then(() => fitPanelContent());
    const onResize = () => {
      syncIsMobilePanel();
      fitPanelContent();
    };
    window.addEventListener('resize', onResize);

    return () => {
      window.removeEventListener('resize', onResize);
    };
  });

  function onContinue() {
    if (hasNext) onnext?.();
    else onclose();
  }

  function isScrollAtBottom() {
    if (!scrollEl) return false;
    return scrollEl.scrollTop + scrollEl.clientHeight >= scrollEl.scrollHeight - 6;
  }

  /** @param {number} deltaY */
  function tryAdvanceFromScroll(deltaY) {
    if (deltaY <= 0) return;
    if (!isScrollAtBottom()) {
      scrollAdvanceAccum = 0;
      return;
    }
    const now = performance.now();
    if (now < scrollAdvanceLockUntil) return;

    scrollAdvanceAccum += deltaY;
    if (scrollAdvanceAccum < SCROLL_ADVANCE_THRESHOLD) return;

    scrollAdvanceAccum = 0;
    scrollAdvanceLockUntil = now + 900;
    onContinue();
  }

  /** @param {WheelEvent} event */
  function onPanelWheel(event) {
    if (!scrollEl) return;

    const deltaY = event.deltaY;
    const atBottom = isScrollAtBottom();

    if (!atBottom || deltaY < 0) {
      event.preventDefault();
      scrollEl.scrollTop += deltaY * SCROLL_WHEEL_FACTOR;
      syncSlider();
      return;
    }

    event.preventDefault();
    tryAdvanceFromScroll(deltaY);
  }

  /** @param {TouchEvent} event */
  function onPanelTouchStart(event) {
    stopTouchPropagation(event);
    const touch = event.touches[0];
    if (!touch) return;
    touchStartY = touch.clientY;
    touchLastY = touch.clientY;
  }

  /** @param {TouchEvent} event */
  function onPanelTouchMove(event) {
    stopTouchPropagation(event);
    const touch = event.touches[0];
    if (!touch) return;
    touchLastY = touch.clientY;
  }

  /** @param {TouchEvent} event */
  function onPanelTouchEnd(event) {
    stopTouchPropagation(event);
    const totalSwipe = touchStartY - touchLastY;
    if (totalSwipe <= 0) return;
    if (!isScrollAtBottom()) return;
    const now = performance.now();
    if (now < scrollAdvanceLockUntil) return;

    if (totalSwipe < TOUCH_ADVANCE_THRESHOLD) return;
    scrollAdvanceLockUntil = now + 900;
    onContinue();
  }

  /** @param {TouchEvent} event */
  function stopTouchPropagation(event) {
    event.stopPropagation();
  }
</script>

<div class="sport-detail">
  <div class="sport-detail-gradients" aria-hidden="true">
    <div class="grad-side"></div>
    <div class="grad-mobile-halo"></div>
  </div>

  <aside
    class="sport-panel"
    bind:this={panelEl}
    aria-labelledby="sport-detail-title"
    ontouchstart={stopTouchPropagation}
    ontouchmove={stopTouchPropagation}
  >
    <div
      class="sport-panel-scroll"
      role="region"
      aria-labelledby="sport-detail-title"
      bind:this={scrollEl}
      onscroll={syncSlider}
      onwheel={onPanelWheel}
      ontouchstart={onPanelTouchStart}
      ontouchmove={onPanelTouchMove}
      ontouchend={onPanelTouchEnd}
    >
      <div class="sport-panel-content" bind:this={contentEl}>
        {#key hotspot.id}
          <h1 id="sport-detail-title" class="sport-title" bind:this={titleEl}>{title}</h1>
          <div class="sport-body">
            {#each bodyLines as line, index}
              <p class:line-spacer={line.trim() === ''} class:line-first={index === 0}>
                {line.trim() === '' ? '\u200b' : line}
              </p>
            {/each}
          </div>
        {/key}
      </div>
    </div>

    <div
      class="sport-text-slider"
      class:sport-text-slider--active={canScroll}
      style:top="{sliderTop}px"
      style:height="{sliderTrackHeight}px"
      aria-hidden="true"
    >
      <!-- svelte-ignore a11y_no_static_element_interactions -->
      <div class="sport-text-slider__track" onpointerdown={onTrackPointerDown}>
        <div
          class="sport-text-slider__thumb"
          style="--scroll-ratio: {scrollRatio}; --thumb-ratio: {thumbRatio}"
          onpointerdown={onThumbPointerDown}
        ></div>
      </div>
    </div>
  </aside>

  <footer class="sport-continue-wrap">
    <button type="button" class="continue-btn" onclick={onContinue}>
      <span class="continue-label">CONTINUA</span>
      <svg class="continue-chevron" viewBox="0 0 21 9" aria-hidden="true" fill="none">
        <path
          d="M1 1.35L10.5 7.65L20 1.35"
          stroke="#161A1F"
          stroke-width="1.5"
          stroke-linecap="round"
          stroke-linejoin="round"
        />
      </svg>
    </button>
  </footer>
</div>

<style>
  .sport-detail {
    position: fixed;
    inset: 0;
    z-index: 50;
    isolation: isolate;
    pointer-events: none;
    --panel-padding-x: clamp(24px, 5.23vw, 79px);
    --panel-right: clamp(24px, 9.13vw, 138px);
    --panel-w: min(401px, calc(100vw - var(--panel-padding-x) - var(--panel-right)));
  }

  .sport-detail-gradients {
    position: absolute;
    inset: 0;
    pointer-events: none;
    z-index: 0;
  }

  .grad-side {
    position: absolute;
    top: 0;
    left: 14%;
    right: 0;
    height: 100%;
    z-index: 0;
    background: linear-gradient(
      to right,
      rgba(249, 249, 250, 0) 0%,
      rgba(249, 249, 250, 0.22) 10%,
      rgba(249, 249, 250, 0.52) 24%,
      rgba(249, 249, 250, 0.82) 38%,
      #f9f9fa 50%
    );
  }

  .grad-mobile-halo {
    display: none;
  }

  .sport-panel {
    position: absolute;
    top: calc(50% + 17px);
    left: auto;
    right: var(--panel-right);
    transform: translateY(-50%);
    width: var(--panel-w);
    max-width: 401px;
    max-height: calc(100vh - clamp(108px, 14vh, 136px));
    z-index: 10;
    /* Serve per evitare il taglio della "prima riga" (text-indent negativo). */
    overflow-x: visible;
    overflow-y: hidden;
    padding: 0;
    box-sizing: border-box;
    pointer-events: auto;
    animation: panelIn 0.45s cubic-bezier(0.22, 1, 0.36, 1) both;
  }

  .sport-panel-scroll {
    position: relative;
    height: 100%;
    overflow-x: visible;
    overflow-y: auto;
    scroll-behavior: smooth;
    -webkit-overflow-scrolling: touch;
    overscroll-behavior: contain;
    box-sizing: border-box;
  }

  .sport-panel-content {
    position: relative;
    width: 100%;
    max-width: 401px;
    padding: 0 0 28px;
    transform-origin: top left;
    z-index: 11;
  }

  .sport-text-slider {
    display: none;
  }

  .sport-title {
    margin: 0 0 20px;
    font-family: 'Supreme', sans-serif;
    font-size: 36px;
    font-weight: 800;
    line-height: normal;
    letter-spacing: 0.2px;
    color: #161a1f;
  }

  .sport-body {
    display: flex;
    flex-direction: column;
    gap: 0;
    width: 100%;
    max-width: 401px;
  }

  .sport-body p {
    margin: 0;
    font-family: 'Supreme', sans-serif;
    font-size: 16px;
    font-weight: 400;
    line-height: normal;
    color: #161a1f;
  }

  .sport-body p.line-first {
    text-indent: 0;
  }

  .sport-body p.line-spacer {
    min-height: 16px;
    line-height: 16px;
  }

  .sport-continue-wrap {
    position: absolute;
    left: auto;
    right: calc(var(--panel-right) + var(--panel-w) / 2);
    bottom: clamp(24px, 4vh, 40px);
    transform: translateX(50%);
    z-index: 51;
    pointer-events: none;
    padding-top: 0;
  }

  .continue-btn {
    font-family: 'Supreme', sans-serif;
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 16px;
    margin: 0;
    padding: 0 14px;
    border: none;
    background: transparent;
    cursor: pointer;
    pointer-events: auto;
  }

  .continue-label {
    font-family: 'Supreme', sans-serif;
    font-size: 16px;
    font-weight: 700;
    line-height: 1.1;
    margin-top: 0;
    text-transform: uppercase;
    color: #161a1f;
  }

  .continue-chevron {
    display: block;
    width: 25px;
    height: 10px;
    animation: chevron-bounce 1.4s ease-in-out infinite;
  }

  @keyframes chevron-bounce {
    0%,
    100% {
      transform: translateY(0);
    }

    50% {
      transform: translateY(5px);
    }
  }

  @keyframes panelIn {
    from {
      opacity: 0;
      transform: translateY(calc(-50% + 18px));
    }
    to {
      opacity: 1;
      transform: translateY(-50%);
    }
  }

  @media (max-width: 900px) {
    .sport-detail {
      --panel-padding-x: 20px;
    }

    .grad-side {
      top: auto;
      bottom: 0;
      left: 0;
      width: 100%;
      height: 72vh;
      background: linear-gradient(
        to top,
        rgba(249, 249, 250, 0.97) 0%,
        rgba(249, 249, 250, 0.94) 38%,
        rgba(249, 249, 250, 0.78) 50%,
        rgba(249, 249, 250, 0.52) 60%,
        rgba(249, 249, 250, 0.28) 68%,
        rgba(249, 249, 250, 0.12) 74%,
        rgba(249, 249, 250, 0.04) 80%,
        rgba(249, 249, 250, 0) 88%
      );
    }

    .grad-mobile-halo {
      display: block;
      position: absolute;
      left: -12%;
      right: -12%;
      bottom: 0;
      height: 72vh;
      background: radial-gradient(
        ellipse 120% 112% at 50% 100%,
        rgba(249, 249, 250, 0.98) 0%,
        rgba(249, 249, 250, 0.92) 36%,
        rgba(249, 249, 250, 0.72) 50%,
        rgba(249, 249, 250, 0.44) 62%,
        rgba(249, 249, 250, 0.2) 72%,
        rgba(249, 249, 250, 0.06) 80%,
        rgba(249, 249, 250, 0) 90%
      );
      pointer-events: none;
    }

    .sport-panel {
      top: auto;
      right: 0;
      left: 0;
      bottom: 64px;
      transform: none;
      width: 100%;
      /* Non compensiamo cambiando anche height: così il box scende davvero. */
      height: calc(50vh - 68px);
      max-height: calc(50vh - 68px);
      display: block;
      /* Evita taglio anche su mobile */
      overflow-x: visible;
      overflow-y: hidden;
      padding: 0;
      background: transparent;
      border-radius: 0;
      animation-name: panelInMobile;
    }

    .sport-panel-scroll {
      height: 100%;
      overflow-x: visible;
      overflow-y: scroll;
      touch-action: pan-y;
      padding-right: calc(17px + var(--panel-padding-x));
      scrollbar-width: none;
      -ms-overflow-style: none;
    }

    .sport-panel-scroll::-webkit-scrollbar {
      display: none;
    }

    .sport-text-slider {
      display: block;
      position: absolute;
      top: 0;
      right: var(--panel-padding-x);
      width: 3px;
      z-index: 2;
      opacity: 0.35;
      transition: opacity 0.2s ease;
      pointer-events: none;
    }

    .sport-text-slider--active {
      opacity: 1;
      pointer-events: auto;
    }

    .sport-text-slider__track {
      position: relative;
      width: 100%;
      height: 100%;
      border-radius: 2px;
      background: rgba(22, 26, 31, 0.12);
      cursor: pointer;
      touch-action: none;
    }

    .sport-text-slider__thumb {
      position: absolute;
      left: 0;
      right: 0;
      border-radius: 2px;
      background: rgba(22, 26, 31, 0.42);
      height: calc(var(--thumb-ratio, 1) * 100%);
      top: calc(var(--scroll-ratio, 0) * (100% - var(--thumb-ratio, 1) * 100%));
      cursor: grab;
      touch-action: none;
    }

    .sport-text-slider__thumb:active {
      cursor: grabbing;
    }

    .sport-panel-content {
      position: relative;
      z-index: 1;
      padding: 20px 0 72px var(--panel-padding-x);
      transform-origin: top center;
    }

    .sport-continue-wrap {
      position: absolute;
      left: 0;
      right: 0;
      bottom: 0;
      transform: none;
      z-index: 51;
      flex-shrink: 0;
      display: flex;
      justify-content: center;
      align-items: center;
      width: 100%;
      margin: 0;
      padding: 64px var(--panel-padding-x) max(18px, env(safe-area-inset-bottom));
      box-sizing: border-box;
      pointer-events: none;
      background: transparent;
    }
  }

  @keyframes panelInMobile {
    from {
      opacity: 0;
      transform: translateY(18px);
    }
    to {
      opacity: 1;
      transform: translateY(0);
    }
  }
</style>
