<script lang="ts">
  import { onMount, tick } from 'svelte';
  import { browser } from '$app/environment';
  import * as THREE from 'three';
  import { createGltfLoader } from '$lib/utils/gltf';
  import type { GLTF } from 'three/examples/jsm/loaders/GLTFLoader.js';

  /**
   * Mountain background scene for the home.
   * Driven entirely by `scrollProgress` (0..1):
   *  - 0 .. ORBIT_END                 camera orbits 1/3 turn around the mountain
   *  - SNOW_DIVE_START .. SNOW_ZONE   dive toward the snow field + whiteout
   *  - SNOW_ZONE .. CARDS_START       white gap (canvas hidden)
   *  - CARDS_START .. CARDS_END       mountain reappears top-down (cards phase)
   */
  let {
    scrollProgress = 0,
    snowZoneAt = 0.62,
    darkMode = false,
    negative = false,
    onReady
  }: {
    scrollProgress?: number;
    snowZoneAt?: number;
    darkMode?: boolean;
    negative?: boolean;
    onReady?: () => void;
  } = $props();

  // --- scroll phase thresholds (must match the home anchors scale) ---
  const ORBIT_END = 0.45;
  const SNOW_DIVE_START = 0.38; // dive start; LOWER = slower/longer dive (spread over more scroll)
  const SNOW_ZOOM_AMP = 1.4;       // dive zoom-in magnitude (was 2.15; LOWER = less "rushing into" the mountain)
  const DEEP_SNOW_BOOST_AMP = 0.4; // extra zoom near the bottom of the dive (was 0.85)
  const CARDS_START = 0.9;
  const CARDS_END = 0.95;

  // --- model + framing constants (tuned to the mountain GLB) ---
  const MOUNTAIN_GLB_URL = '/models/snow-mountain.glb';
  const MOUNTAIN_ROTATION_Y = Math.PI / 2 + 0.12; // slight offset from 90°
  const CAM_Y_LOW = -2.9; // hero camera height
  const ORBIT_LOOKAT_Y = 0.8; // look-at height above mountain center (matches the prototype)
  const CARDS_TILT = 0.8; // cards-phase tilt: 0 = straight down, higher = more angled
  // total arc is less than a full turn now; the dive must still start from the same fixed
  // orientation as before, so the hero (scroll 0) angle is shifted back by that same amount
  const ORBIT_TURNS = 0.35; // fraction of a full turn during the intro (1 = full, like proto)
  const ORBIT_ARC = ORBIT_TURNS * Math.PI * 2;
  const FOG_COLOR_LIGHT = '#ffffff';
  const FOG_COLOR_DARK = '#161A1F';

  let container: HTMLDivElement | undefined = $state(undefined);
  let renderer: THREE.WebGLRenderer | undefined;
  let scene: THREE.Scene | undefined;
  let camera: THREE.PerspectiveCamera | undefined;
  let sceneFog: THREE.FogExp2 | undefined;
  let animationFrameId = 0;
  let snowMountainModel: THREE.Group | undefined;
  let initGeneration = 0;

  type OrbitConfig = {
    center: THREE.Vector3;
    snowField: THREE.Vector3;
    startAngle: number;
    orbitY: number;
    radius: number;
    topDownHeight: number;
  };

  type MountainMaterial = {
    material: THREE.Material;
    originalColor: THREE.Color;
    darkTargetColor: THREE.Color;
  };

  let orbitConfig: OrbitConfig | null = null;
  let mountainMaterials: MountainMaterial[] = [];

  // scratch vectors (avoid per-frame allocations)
  const _camPos = new THREE.Vector3();
  const _lookAt = new THREE.Vector3();
  const _orbitEndPos = new THREE.Vector3();
  const _orbitEndLookAt = new THREE.Vector3();
  const _snowApproachPos = new THREE.Vector3();
  const _snowApproachLookAt = new THREE.Vector3();
  const _snowCamPos = new THREE.Vector3();
  const _snowLookAt = new THREE.Vector3();
  const _snowDir = new THREE.Vector3();
  const _whiteColor = new THREE.Color(0xffffff);
  const _darkSnowColor = new THREE.Color(0x161A1F);
  const _darkRockColor = new THREE.Color(0xf4f6f8);

  function luma(c: THREE.Color): number {
    // Rec. 709 luma
    return 0.2126 * c.r + 0.7152 * c.g + 0.0722 * c.b;
  }

  // Threshold to decide "snow-like" vs "rock-like" materials in the GLB.
  // Snow materials are expected to be much brighter in the original model.
  const SNOW_LUMA_THRESHOLD = 0.72;

  // --- math helpers ---
  const clamp = (v: number, min: number, max: number): number => Math.min(max, Math.max(min, v));
  const lerp = (a: number, b: number, t: number): number => a + (b - a) * t;
  const easeInOutCubic = (t: number): number =>
    t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;
  const easeInOutQuint = (t: number): number =>
    t < 0.5 ? 16 * t * t * t * t * t : 1 - Math.pow(-2 * t + 2, 5) / 2;
  function smoothstep(edge0: number, edge1: number, x: number): number {
    const t = clamp((x - edge0) / (edge1 - edge0), 0, 1);
    return t * t * (3 - 2 * t);
  }
  const easeInOutSine = (t: number) => -(Math.cos(Math.PI * clamp(t, 0, 1)) - 1) / 2;

  // --- mountain GLB load + fit (no DRACO; our GLBs are uncompressed) ---
  let loadPromise: Promise<GLTF> | null = null;
  function preloadMountainGltf(): Promise<GLTF> {
    THREE.Cache.enabled = true;
    if (!loadPromise) {
      loadPromise = new Promise<GLTF>((resolve, reject) => {
        const loader = createGltfLoader();
        loader.load(MOUNTAIN_GLB_URL, resolve, undefined, (err) => {
          loadPromise = null;
          reject(err);
        });
      });
    }
    return loadPromise;
  }

  function fitMountainModel(model: THREE.Group): {
    mountainCenter: THREE.Vector3;
    snowField: THREE.Vector3;
    orbitRadius: number;
    topDownHeight: number;
  } {
    model.rotation.set(0, MOUNTAIN_ROTATION_Y, 0);
    model.updateMatrixWorld(true);

    const box = new THREE.Box3().setFromObject(model);
    const center = box.getCenter(new THREE.Vector3());
    const size = box.getSize(new THREE.Vector3());
    const desiredSize = 45.0;
    const scaleFactor = desiredSize / Math.max(size.x, size.y, size.z);

    model.scale.set(scaleFactor, scaleFactor, scaleFactor);
    model.position.x = -center.x * scaleFactor - 2.5;
    model.position.y = -center.y * scaleFactor - 1.5; // mountain vertical position (raise = less negative)
    model.position.z = -center.z * scaleFactor - 10.5;
    model.updateMatrixWorld(true);

    const worldBox = new THREE.Box3().setFromObject(model);
    const worldSize = worldBox.getSize(new THREE.Vector3());
    const mountainCenter = worldBox.getCenter(new THREE.Vector3());

    const snowField = mountainCenter.clone();
    snowField.y = worldBox.min.y + worldSize.y * 0.16;
    const orbitRadius = Math.max(worldSize.x, worldSize.z) * 0.58 + 7;
    const topDownHeight = Math.max(worldSize.x, worldSize.z) * 0.52 + 8;

    return { mountainCenter, snowField, orbitRadius, topDownHeight };
  }

  function waitForContainerSize(el: HTMLElement | undefined, maxFrames = 40): Promise<void> {
    return new Promise<void>((resolve) => {
      let frames = 0;
      const check = () => {
        if (el && el.clientWidth > 0 && el.clientHeight > 0) return resolve();
        if (frames++ >= maxFrames) return resolve();
        requestAnimationFrame(check);
      };
      check();
    });
  }

  // --- camera choreography ---
  function zoomAt(scroll: number): number {
    const orbitU = clamp(scroll / Math.max(ORBIT_END, 0.01), 0, 1);
    const orbitZoom = easeInOutCubic(orbitU) * 0.85;
    const snowU = smoothstep(SNOW_DIVE_START, snowZoneAt, scroll);
    const snowZoom = easeInOutCubic(snowU) * SNOW_ZOOM_AMP;
    const deepSnowBoost = easeInOutCubic(smoothstep(0.55, 1, snowU)) * DEEP_SNOW_BOOST_AMP;
    return 1.2 + orbitZoom + snowZoom + deepSnowBoost;
  }

  function positionOnOrbit(angle: number, radius: number, cfg: OrbitConfig, target: THREE.Vector3): void {
    target.set(
      cfg.center.x + Math.sin(angle) * radius,
      cfg.orbitY,
      cfg.center.z + Math.cos(angle) * radius
    );
  }

  // cfg.startAngle is the fixed orientation the mountain must reach right before the snow
  // dive; since the visible orbit now covers less than a full turn, the hero (scroll 0)
  // angle is shifted back by the same amount so the dive always starts from that fixed spot.
  function orbitAngleAt(scroll: number, cfg: OrbitConfig): number {
    // start facing the hero-front, rotate forward by ORBIT_ARC across the orbit span
    const t = clamp(scroll / Math.max(ORBIT_END, 0.001), 0, 1);
    return cfg.startAngle + ORBIT_ARC * easeInOutSine(t);
  }

  function sampleCameraAt(scroll: number): boolean {
    const cfg = orbitConfig;
    if (!cfg) return false;

    const endAngle = cfg.startAngle + ORBIT_ARC;

    if (scroll <= SNOW_DIVE_START) {
      const angle = orbitAngleAt(scroll, cfg);
      positionOnOrbit(angle, cfg.radius, cfg, _camPos);
      _lookAt.copy(cfg.center).add(new THREE.Vector3(0, ORBIT_LOOKAT_Y, 0));
      return true;
    }

    positionOnOrbit(endAngle, cfg.radius, cfg, _orbitEndPos);
    _orbitEndLookAt.copy(cfg.center).add(new THREE.Vector3(0, ORBIT_LOOKAT_Y, 0));

    _snowDir.set(cfg.snowField.x - _orbitEndPos.x, 0, cfg.snowField.z - _orbitEndPos.z);
    if (_snowDir.lengthSq() < 0.01) {
      _snowDir.set(cfg.snowField.x - cfg.center.x, 0, cfg.snowField.z - cfg.center.z);
    }
    if (_snowDir.lengthSq() < 0.01) _snowDir.set(0, 0, -1);
    else _snowDir.normalize();

    _snowApproachPos.copy(cfg.snowField).addScaledVector(_snowDir, -6.5);
    _snowApproachPos.y = cfg.snowField.y + 4.2;
    _snowApproachLookAt.copy(cfg.snowField);

    _snowCamPos.copy(cfg.snowField);
    _snowCamPos.y += 0.4;
    _snowLookAt.copy(_snowCamPos).addScaledVector(_snowDir, 10);
    _snowLookAt.y -= 0.2;

    const snowT = smoothstep(SNOW_DIVE_START, snowZoneAt, scroll);
    const eased = easeInOutCubic(snowT);

    if (eased < 0.34) {
      const te = easeInOutCubic(eased / 0.34);
      _camPos.lerpVectors(_orbitEndPos, _snowApproachPos, te);
      _lookAt.lerpVectors(_orbitEndLookAt, _snowApproachLookAt, te);
    } else {
      const te = easeInOutQuint((eased - 0.34) / 0.66);
      _camPos.lerpVectors(_snowApproachPos, _snowCamPos, te);
      _lookAt.lerpVectors(_snowApproachLookAt, _snowLookAt, te);
    }
    return true;
  }

  function applySnowWhiteout(scroll: number): void {
    const whiteT = smoothstep(SNOW_DIVE_START, snowZoneAt, scroll);
    const insideT = smoothstep(0.08, 0.34, whiteT);
    if (!snowMountainModel) return;

    snowMountainModel.visible = insideT < 0.97;
    if (!snowMountainModel.visible) return;

    const meshOpacity = 1 - insideT * 0.96;
    for (const { material, originalColor, darkTargetColor } of mountainMaterials) {
      if ('color' in material && material.color instanceof THREE.Color) {
        const target = darkMode ? darkTargetColor : _whiteColor;
        material.color.copy(originalColor).lerp(target, insideT * 0.9);
      }
      material.opacity = meshOpacity;
    }
  }

  function sampleTopDownCamera(cardsT: number) {
    const cfg = orbitConfig;
    if (!cfg) return false;
    const eased = easeInOutCubic(clamp(cardsT, 0, 1));
    const height = cfg.topDownHeight * lerp(1.12, 1, eased);
    // pull the camera back along -Z as we tilt, so the view is angled (not straight down)
    const back = Math.sin(CARDS_TILT) * height;
    const up = Math.cos(CARDS_TILT) * height;
    _camPos.set(cfg.center.x, cfg.center.y + up, cfg.center.z - back);
    _lookAt.copy(cfg.center);
    return true;
  }

  function buildOrbitConfig(
    mountainCenter: THREE.Vector3,
    snowField: THREE.Vector3,
    orbitRadius: number,
    topDownHeight: number
  ): void {
    const c = mountainCenter;
    const startCam = new THREE.Vector3(0, CAM_Y_LOW, 7.8);
    const dx = startCam.x - c.x;
    const dz = startCam.z - c.z;
    const startAngle = Math.atan2(dx, dz);
    const heroRadius = Math.hypot(dx, dz);

    orbitConfig = {
      center: c.clone(),
      snowField: snowField.clone(),
      startAngle,
      orbitY: c.y + CAM_Y_LOW + 1.1,
      radius: Math.max(orbitRadius, heroRadius, 12) * 0.82,
      topDownHeight
    };
  }

  function setupMountainMaterials(object: THREE.Object3D): void {
    mountainMaterials = [];
    object.traverse((o: THREE.Object3D) => {
      if (!(o instanceof THREE.Mesh)) return;
      const materials = Array.isArray(o.material) ? o.material : [o.material];
      const cloned = materials.map((mat) => {
        const material = mat.clone();
        material.transparent = true;
        material.fog = true;
        material.side = THREE.FrontSide;
        const color =
          'color' in material && material.color instanceof THREE.Color
            ? material.color.clone()
            : new THREE.Color(0xffffff);
        const darkTargetColor =
          luma(color) > SNOW_LUMA_THRESHOLD ? _darkSnowColor : _darkRockColor;
        mountainMaterials.push({ material, originalColor: color, darkTargetColor });
        return material;
      });
      o.material = cloned.length === 1 ? cloned[0] : cloned;
    });
  }

  function setMountainVisible(visible: boolean): void {
    if (!snowMountainModel) return;
    snowMountainModel.visible = visible;
    if (!visible) return;
    for (const { material, originalColor, darkTargetColor } of mountainMaterials) {
      if ('color' in material && material.color instanceof THREE.Color) {
        material.color.copy(darkMode ? darkTargetColor : originalColor);
      }
      material.opacity = 1;
    }
  }

  function resizeRenderer(): void {
    if (!container || !camera || !renderer) return;
    const w = container.clientWidth;
    const h = container.clientHeight;
    if (w <= 0 || h <= 0) return;
    camera.aspect = w / h;
    camera.updateProjectionMatrix();
    renderer.setSize(w, h);
  }

  function animate(): void {
    if (!renderer || !scene || !camera) return;
    animationFrameId = requestAnimationFrame(animate);

    const progress = scrollProgress;
    const inSnowGap = progress >= snowZoneAt && progress < CARDS_START;
    const inCardsPhase = progress >= CARDS_START;

    if (inSnowGap) {
      if (snowMountainModel) snowMountainModel.visible = false;
      renderer.domElement.style.visibility = 'hidden';
      renderer.domElement.style.opacity = '0';
      return;
    }

    if (inCardsPhase) {
      const cardsT = smoothstep(CARDS_START, CARDS_END, progress);
      renderer.domElement.style.visibility = 'visible';
      renderer.domElement.style.opacity = String(cardsT);

      setMountainVisible(true);
      if (sampleTopDownCamera(cardsT)) {
        camera.position.copy(_camPos);
        camera.up.set(0, 1, 0);
        camera.lookAt(_lookAt);
      }
      camera.zoom = lerp(1.05, 1.28, easeInOutCubic(cardsT));
      camera.updateProjectionMatrix();

      if (sceneFog) {
        sceneFog.density = lerp(0.03, 0.022, cardsT);
        if (darkMode) sceneFog.color.copy(_darkSnowColor);
        else sceneFog.color.setRGB(1, 1, 1);
      }
      renderer.setClearColor(darkMode ? 0x161A1F : 0xffffff, 1);
      renderer.render(scene, camera);
      return;
    }

    renderer.domElement.style.visibility = 'visible';
    renderer.domElement.style.opacity = '1';

    const scroll = clamp(progress, 0, snowZoneAt);
    if (sampleCameraAt(scroll)) {
      camera.position.copy(_camPos);
      camera.up.set(0, 1, 0);
      camera.lookAt(_lookAt);
    } else {
      camera.position.set(0, CAM_Y_LOW, 7.8);
      camera.up.set(0, 1, 0);
      camera.lookAt(0, 0, 0);
    }

    camera.zoom = zoomAt(scroll);
    camera.updateProjectionMatrix();

    const whiteT = smoothstep(SNOW_DIVE_START, snowZoneAt, scroll);
    const insideFog = smoothstep(0.28, 1, whiteT);
    if (sceneFog) {
      sceneFog.density = lerp(0.045, 0.38, insideFog);
      if (darkMode) sceneFog.color.copy(_darkSnowColor);
      else sceneFog.color.setRGB(1, 1, 1);
    }

    if (whiteT > 0.02) applySnowWhiteout(scroll);
    else setMountainVisible(true);

    renderer.setClearColor(darkMode ? 0x161A1F : 0xffffff, 1);
    renderer.render(scene, camera);
  }

  function teardown(): void {
    initGeneration += 1;
    cancelAnimationFrame(animationFrameId);
    window.removeEventListener('resize', resizeRenderer);

    if (snowMountainModel && scene) {
      scene.remove(snowMountainModel);
      snowMountainModel.traverse((o: THREE.Object3D) => {
        if (!(o instanceof THREE.Mesh)) return;
        o.geometry?.dispose();
        const mats = Array.isArray(o.material) ? o.material : [o.material];
        mats.forEach((m: THREE.Material) => m.dispose());
      });
      snowMountainModel = undefined;
    }

    mountainMaterials = [];
    orbitConfig = null;
    if (renderer) {
      renderer.dispose();
      renderer.domElement.remove();
      renderer = undefined;
    }
    scene = undefined;
    camera = undefined;
    sceneFog = undefined;
  }

  onMount(() => {
    if (!browser) return;

    const gen = ++initGeneration;
    (async () => {
      await tick();
      await waitForContainerSize(container);
      if (gen !== initGeneration || !container) return;

      scene = new THREE.Scene();
      sceneFog = new THREE.FogExp2(darkMode ? FOG_COLOR_DARK : FOG_COLOR_LIGHT, 0.045);
      scene.fog = sceneFog;

      const w = Math.max(container.clientWidth, 1);
      const h = Math.max(container.clientHeight, 1);

      camera = new THREE.PerspectiveCamera(44, w / h, 0.1, 500);
      camera.position.set(0, CAM_Y_LOW, 7.8);

      renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
      renderer.setSize(w, h);
      renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
      container.appendChild(renderer.domElement);

      scene.add(new THREE.AmbientLight(0xffffff, 2.0));
      const directionalLight = new THREE.DirectionalLight(0xeaeff5, 2.5);
      directionalLight.position.set(5, 10, 7);
      scene.add(directionalLight);

      animate();
      window.addEventListener('resize', resizeRenderer);

      try {
        const gltf = await preloadMountainGltf();
        if (gen !== initGeneration || !scene) return;

        snowMountainModel = gltf.scene.clone(true);
        const { mountainCenter, snowField, orbitRadius, topDownHeight } =
          fitMountainModel(snowMountainModel);
        buildOrbitConfig(mountainCenter, snowField, orbitRadius, topDownHeight);
        setupMountainMaterials(snowMountainModel);
        scene.add(snowMountainModel);
        resizeRenderer();
        // let the parent fade the canvas in once the first frame has rendered
        requestAnimationFrame(() => requestAnimationFrame(() => onReady?.()));
      } catch (err) {
        console.error('[MountainScene] mountain load failed:', err);
      }
    })();

    return teardown;
  });
</script>

<div class="mountain-scene" class:is-negative={negative} bind:this={container}></div>

<style>
  .mountain-scene {
    width: 100%;
    height: 100%;
    background: #ffffff;
    filter: grayscale(1); /* render the mountain in black & white everywhere */
  }

  .mountain-scene.is-negative {
    /* neve bianca -> nera, roccia scura -> chiara */
    filter: grayscale(1) invert(1);
  }
</style>
